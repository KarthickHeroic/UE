import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RptItemSalesPage } from './rpt-item-sales';

@NgModule({
  declarations: [
    RptItemSalesPage,
  ],
  imports: [
    IonicPageModule.forChild(RptItemSalesPage),
  ],
})
export class RptItemSalesPageModule {}
