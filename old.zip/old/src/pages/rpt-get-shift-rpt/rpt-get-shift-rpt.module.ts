import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RptGetShiftRptPage } from './rpt-get-shift-rpt';

@NgModule({
  declarations: [
    RptGetShiftRptPage,
  ],
  imports: [
    IonicPageModule.forChild(RptGetShiftRptPage),
  ],
})
export class RptGetShiftRptPageModule {}
