import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SalesPosRptPage } from './sales-pos-rpt';

@NgModule({
  declarations: [
    SalesPosRptPage,
  ],
  imports: [
    IonicPageModule.forChild(SalesPosRptPage),
  ],
})
export class SalesPosRptPageModule {}
