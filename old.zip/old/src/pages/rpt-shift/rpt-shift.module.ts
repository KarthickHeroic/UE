import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RptShiftPage } from './rpt-shift';

@NgModule({
  declarations: [
    RptShiftPage,
  ],
  imports: [
    IonicPageModule.forChild(RptShiftPage),
  ],
})
export class RptShiftPageModule {}
