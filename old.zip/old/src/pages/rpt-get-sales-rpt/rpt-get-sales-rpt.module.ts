import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RptGetSalesRptPage } from './rpt-get-sales-rpt';

@NgModule({
  declarations: [
    RptGetSalesRptPage,
  ],
  imports: [
    IonicPageModule.forChild(RptGetSalesRptPage),
  ],
})
export class RptGetSalesRptPageModule {}
